# NexoFit Gym Website

## Overview

A modern, responsive website for NexoFit - a leading gym in Tegucigalpa specializing in young athletes. The application features a single-page design with comprehensive sections including hero, mission/vision, pricing plans, services, gallery, testimonials, and contact form. Built with React and Express, it emphasizes performance, user experience, and conversion optimization for the fitness industry.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript for type safety and modern development
- **Styling**: Tailwind CSS with custom design system using black, red, and white color scheme
- **UI Components**: shadcn/ui component library built on Radix UI primitives for accessibility
- **State Management**: TanStack Query for server state management and form handling with React Hook Form
- **Routing**: Wouter for lightweight client-side routing
- **Build Tool**: Vite for fast development and optimized production builds

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript throughout the entire application
- **API Design**: RESTful endpoints with proper error handling and validation
- **Data Validation**: Zod schemas for runtime type checking and form validation
- **Development**: Hot module replacement and runtime error overlay for development experience

### Database Layer
- **ORM**: Drizzle ORM for type-safe database operations
- **Database**: PostgreSQL with Neon serverless configuration
- **Schema Management**: Drizzle migrations with shared schema definitions
- **Session Storage**: PostgreSQL-based session storage using connect-pg-simple

### Form Handling & Validation
- **Client-side**: React Hook Form with Zod resolvers for comprehensive validation
- **Server-side**: Zod schema validation with proper error responses
- **User Feedback**: Toast notifications for success/error states

### Responsive Design
- **Mobile-first**: Tailwind CSS responsive utilities
- **Typography**: Google Fonts (Montserrat and Inter) for brand consistency
- **Animations**: CSS transitions and scroll-based reveal animations
- **Performance**: Image optimization with Unsplash CDN integration

## External Dependencies

### Core Technologies
- **@neondatabase/serverless**: PostgreSQL database connection for serverless environments
- **drizzle-orm**: Type-safe SQL toolkit and ORM
- **@tanstack/react-query**: Server state management and caching
- **react-hook-form**: Performant form library with validation

### UI Component Libraries
- **@radix-ui/react-***: Comprehensive set of accessible UI primitives
- **lucide-react**: Modern icon library
- **class-variance-authority**: Type-safe utility for creating component variants
- **tailwindcss**: Utility-first CSS framework

### Development Tools
- **vite**: Next-generation frontend tooling
- **typescript**: Static type checking
- **@replit/vite-plugin-runtime-error-modal**: Development error handling
- **wouter**: Minimalist routing library

### Image Assets
- **Unsplash**: Professional gym and fitness photography via CDN
- **Custom brand assets**: NexoFit logo and branding elements

### Third-party Services
- **Google Fonts**: Typography delivery (Montserrat, Inter)
- **Social Media Integrations**: Placeholder implementations for Instagram, Facebook, YouTube
- **Maps Integration**: Prepared for Google Maps integration in contact section