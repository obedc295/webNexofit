const galleryImages = [
  {
    id: "deadlifts",
    src: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600",
    alt: "Atleta joven realizando peso muerto",
  },
  {
    id: "equipment",
    src: "https://images.unsplash.com/photo-1540497077202-7c8a3999166f?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600",
    alt: "Equipamiento moderno de gimnasio",
  },
  {
    id: "female-athlete",
    src: "https://images.unsplash.com/photo-1594737625785-a6cbdabd333c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600",
    alt: "Atleta femenina entrenando fuerza",
  },
  {
    id: "cardio",
    src: "https://images.unsplash.com/photo-1571902943202-507ec2618e8f?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600",
    alt: "Área de cardio con tecnología avanzada",
  },
  {
    id: "group-training",
    src: "https://images.unsplash.com/photo-1549060279-7e168fcee0c2?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600",
    alt: "Grupo de jóvenes atletas entrenando juntos",
  },
  {
    id: "supplements",
    src: "https://images.unsplash.com/photo-1544991875-5dc1b05f607d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600",
    alt: "Suplementos premium de alta calidad",
  },
  {
    id: "personal-training",
    src: "https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600",
    alt: "Sesión de entrenamiento personal",
  },
  {
    id: "interior",
    src: "https://images.unsplash.com/photo-1534438327276-14e5300c3a48?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600",
    alt: "Interior moderno del gimnasio con acentos rojos",
  },
];

export default function Gallery() {
  return (
    <section 
      id="galeria" 
      className="py-20 bg-white"
      data-testid="gallery-section"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16 scroll-reveal">
          <h2 
            className="font-montserrat font-bold text-4xl md:text-5xl text-nexo-black mb-4"
            data-testid="section-title"
          >
            Nuestra <span className="text-nexo-red">Galería</span>
          </h2>
          <p 
            className="text-xl text-gray-600 max-w-3xl mx-auto"
            data-testid="section-subtitle"
          >
            Descubre las instalaciones y la comunidad de atletas que entrenan en NexoFit
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {galleryImages.map((image, index) => (
            <div key={image.id} className="scroll-reveal">
              <img
                src={image.src}
                alt={image.alt}
                className="w-full h-48 object-cover rounded-xl hover:transform hover:scale-105 transition-all duration-300 cursor-pointer shadow-lg"
                data-testid={`gallery-image-${image.id}`}
              />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
