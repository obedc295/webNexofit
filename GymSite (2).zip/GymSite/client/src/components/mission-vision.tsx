import { Target, Eye } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

export default function MissionVision() {
  return (
    <section 
      id="mision-vision" 
      className="py-20 bg-nexo-gray"
      data-testid="mission-vision-section"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16 scroll-reveal">
          <h2 
            className="font-montserrat font-bold text-4xl md:text-5xl text-nexo-black mb-4"
            data-testid="section-title"
          >
            Nuestra <span className="text-nexo-red">Filosofía</span>
          </h2>
          <p 
            className="text-xl text-gray-600 max-w-3xl mx-auto"
            data-testid="section-subtitle"
          >
            Empoderamos a la juventud atleta de Tegucigalpa con una experiencia de entrenamiento integral
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-12 items-center">
          {/* Mission */}
          <div className="scroll-reveal">
            <Card className="bg-white p-8 rounded-2xl shadow-lg card-hover" data-testid="mission-card">
              <CardContent className="p-0">
                <div className="flex items-center mb-6">
                  <div className="bg-nexo-red text-white p-4 rounded-full mr-4">
                    <Target size={32} />
                  </div>
                  <h3 className="font-montserrat font-bold text-2xl text-nexo-black">
                    Misión
                  </h3>
                </div>
                <p className="text-gray-700 leading-relaxed" data-testid="mission-text">
                  Somos el gimnasio líder y accesible que impulsa el máximo rendimiento. Empoderamos a la juventud atleta
                  de Tegucigalpa ofreciendo una experiencia de entrenamiento integral y personalizada a través de
                  tecnología de vanguardia, suplementos esenciales y equipamiento innovador.
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Vision */}
          <div className="scroll-reveal">
            <Card className="bg-nexo-black text-white p-8 rounded-2xl shadow-lg card-hover" data-testid="vision-card">
              <CardContent className="p-0">
                <div className="flex items-center mb-6">
                  <div className="bg-nexo-red text-white p-4 rounded-full mr-4">
                    <Eye size={32} />
                  </div>
                  <h3 className="font-montserrat font-bold text-2xl">Visión 2028</h3>
                </div>
                <p className="text-gray-300 leading-relaxed" data-testid="vision-text">
                  Ser el gimnasio de referencia indiscutible en Tegucigalpa para el segmento joven y atleta.
                  Nos destacaremos por nuestra propuesta de valor imbatible, combinando tecnología de punta,
                  personalización efectiva y precios competitivos.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
}
