import { Zap, Play, ChevronDown } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Hero() {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  };

  const handleJoinNow = () => {
    scrollToSection("contacto");
  };

  const handleWatchVideo = () => {
    // Placeholder for video modal or redirect
    alert("Reproduciendo video promocional...");
  };

  return (
    <section 
      id="inicio" 
      className="relative h-screen flex items-center justify-center overflow-hidden"
      data-testid="hero-section"
    >
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <img
          src="https://images.unsplash.com/photo-1534438327276-14e5300c3a48?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1920&h=1080"
          alt="Jóvenes atletas entrenando en gimnasio moderno"
          className="w-full h-full object-cover"
          data-testid="hero-background-image"
        />
      </div>
      
      {/* Gradient Overlay */}
      <div className="absolute inset-0 hero-gradient z-10"></div>

      {/* Hero Content */}
      <div className="relative z-20 text-center text-white max-w-4xl mx-auto px-4">
        <h1 
          className="font-montserrat font-black text-5xl md:text-7xl lg:text-8xl mb-6 leading-tight"
          data-testid="hero-title"
        >
          TRANSFORMA
          <br />
          TU <span className="text-nexo-red">POTENCIAL</span>
        </h1>
        
        <p 
          className="text-xl md:text-2xl mb-8 font-medium max-w-2xl mx-auto leading-relaxed"
          data-testid="hero-subtitle"
        >
          El gimnasio líder en Tegucigalpa especializado en jóvenes atletas.
          Desarrolla fuerza, resistencia y agilidad con tecnología de vanguardia.
        </p>
        
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button
            onClick={handleJoinNow}
            className="btn-primary text-white px-8 py-4 rounded-full text-lg font-semibold flex items-center justify-center"
            data-testid="button-join-now-hero"
          >
            <Zap className="mr-2" size={20} />
            Únete Ahora
          </Button>
          
          <Button
            onClick={handleWatchVideo}
            variant="outline"
            className="border-2 border-white text-white px-8 py-4 rounded-full text-lg font-semibold hover:bg-white hover:text-nexo-black transition-all bg-transparent"
            data-testid="button-watch-video"
          >
            <Play className="mr-2" size={20} />
            Ver Video
          </Button>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 text-white animate-bounce">
        <ChevronDown size={32} data-testid="scroll-indicator" />
      </div>
    </section>
  );
}
