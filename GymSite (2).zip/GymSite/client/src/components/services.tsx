import { Dumbbell, Smartphone, Pill, Settings } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

const services = [
  {
    id: "training",
    icon: Dumbbell,
    title: "Entrenamiento Personalizado",
    description: "Planes de entrenamiento diseñados específicamente para tus objetivos y nivel de condición física.",
  },
  {
    id: "app",
    icon: Smartphone,
    title: "App de Vanguardia",
    description: "Tecnología móvil avanzada para seguimiento de progreso, rutinas y análisis de rendimiento.",
  },
  {
    id: "supplements",
    icon: Pill,
    title: "Suplementos Esenciales",
    description: "Productos de alta calidad para optimizar tu recuperación y maximizar tus resultados.",
  },
  {
    id: "equipment",
    icon: Settings,
    title: "Equipamiento Moderno",
    description: "Maquinaria de última generación y equipos especializados para entrenamiento de élite.",
  },
];

export default function Services() {
  return (
    <section 
      id="servicios" 
      className="py-20 bg-nexo-gray"
      data-testid="services-section"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16 scroll-reveal">
          <h2 
            className="font-montserrat font-bold text-4xl md:text-5xl text-nexo-black mb-4"
            data-testid="section-title"
          >
            Nuestros <span className="text-nexo-red">Servicios</span>
          </h2>
          <p 
            className="text-xl text-gray-600 max-w-3xl mx-auto"
            data-testid="section-subtitle"
          >
            Todo lo que necesitas para alcanzar tu máximo potencial atlético
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {services.map((service, index) => {
            const IconComponent = service.icon;
            return (
              <div key={service.id} className="scroll-reveal">
                <Card 
                  className="bg-white rounded-2xl p-6 text-center card-hover"
                  data-testid={`service-card-${service.id}`}
                >
                  <CardContent className="p-0">
                    <div className="bg-nexo-red text-white w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                      <IconComponent size={32} />
                    </div>
                    <h3 
                      className="font-montserrat font-bold text-xl text-nexo-black mb-3"
                      data-testid={`service-title-${service.id}`}
                    >
                      {service.title}
                    </h3>
                    <p 
                      className="text-gray-600 leading-relaxed"
                      data-testid={`service-description-${service.id}`}
                    >
                      {service.description}
                    </p>
                  </CardContent>
                </Card>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
