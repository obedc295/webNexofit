import { useState } from "react";
import { MapPin, Phone, Mail, Clock, Instagram, Facebook, Youtube } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { insertContactSchema, type InsertContact } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";

const extendedContactSchema = insertContactSchema.extend({
  firstName: insertContactSchema.shape.firstName.min(1, "El nombre es requerido"),
  lastName: insertContactSchema.shape.lastName.min(1, "El apellido es requerido"),
  email: insertContactSchema.shape.email.email("Email inválido"),
});

export default function Contact() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<InsertContact>({
    resolver: zodResolver(extendedContactSchema),
    defaultValues: {
      firstName: "",
      lastName: "",
      email: "",
      phone: "",
      sport: "",
      message: "",
    },
  });

  const contactMutation = useMutation({
    mutationFn: async (data: InsertContact) => {
      return apiRequest("POST", "/api/contact", data);
    },
    onSuccess: () => {
      toast({
        title: "¡Mensaje enviado!",
        description: "Te contactaremos pronto para ayudarte a comenzar tu transformación.",
      });
      form.reset();
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Hubo un problema enviando tu mensaje. Inténtalo de nuevo.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: InsertContact) => {
    contactMutation.mutate(data);
  };

  const handleSocialClick = (platform: string) => {
    // Placeholder for social media links
    alert(`Redirigiendo a ${platform}...`);
  };

  return (
    <section 
      id="contacto" 
      className="py-20 bg-nexo-gray"
      data-testid="contact-section"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16 scroll-reveal">
          <h2 
            className="font-montserrat font-bold text-4xl md:text-5xl text-nexo-black mb-4"
            data-testid="section-title"
          >
            ¿Listo Para <span className="text-nexo-red">Comenzar?</span>
          </h2>
          <p 
            className="text-xl text-gray-600 max-w-3xl mx-auto"
            data-testid="section-subtitle"
          >
            Contáctanos y da el primer paso hacia tu transformación atlética
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Contact Form */}
          <div className="scroll-reveal">
            <Card className="bg-white p-8 rounded-2xl shadow-lg" data-testid="contact-form-card">
              <CardContent className="p-0">
                <h3 className="font-montserrat font-bold text-2xl text-nexo-black mb-6">
                  Envíanos un Mensaje
                </h3>

                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                    <div className="grid md:grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="firstName"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Nombre</FormLabel>
                            <FormControl>
                              <Input
                                placeholder="Tu nombre completo"
                                className="focus:ring-2 focus:ring-nexo-red focus:border-transparent"
                                data-testid="input-firstName"
                                {...field}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="lastName"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Apellido</FormLabel>
                            <FormControl>
                              <Input
                                placeholder="Tu apellido"
                                className="focus:ring-2 focus:ring-nexo-red focus:border-transparent"
                                data-testid="input-lastName"
                                {...field}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <FormField
                      control={form.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email</FormLabel>
                          <FormControl>
                            <Input
                              type="email"
                              placeholder="tu@email.com"
                              className="focus:ring-2 focus:ring-nexo-red focus:border-transparent"
                              data-testid="input-email"
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="phone"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Teléfono</FormLabel>
                          <FormControl>
                            <Input
                              type="tel"
                              placeholder="+504 xxxx-xxxx"
                              className="focus:ring-2 focus:ring-nexo-red focus:border-transparent"
                              data-testid="input-phone"
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="sport"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Deporte/Interés</FormLabel>
                          <Select onValueChange={field.onChange} value={field.value || ""}>
                            <FormControl>
                              <SelectTrigger 
                                className="focus:ring-2 focus:ring-nexo-red focus:border-transparent"
                                data-testid="select-sport"
                              >
                                <SelectValue placeholder="Selecciona tu deporte" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="futbol">Fútbol</SelectItem>
                              <SelectItem value="basketball">Basketball</SelectItem>
                              <SelectItem value="atletismo">Atletismo</SelectItem>
                              <SelectItem value="crossfit">CrossFit</SelectItem>
                              <SelectItem value="fitness">Fitness General</SelectItem>
                              <SelectItem value="otro">Otro</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="message"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Mensaje</FormLabel>
                          <FormControl>
                            <Textarea
                              rows={4}
                              placeholder="Cuéntanos sobre tus objetivos..."
                              className="focus:ring-2 focus:ring-nexo-red focus:border-transparent"
                              data-testid="textarea-message"
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <Button
                      type="submit"
                      disabled={contactMutation.isPending}
                      className="w-full btn-primary text-white py-4 rounded-lg font-semibold"
                      data-testid="button-submit-contact"
                    >
                      <Mail className="mr-2" size={20} />
                      {contactMutation.isPending ? "Enviando..." : "Enviar Mensaje"}
                    </Button>
                  </form>
                </Form>
              </CardContent>
            </Card>
          </div>

          {/* Contact Info & Map */}
          <div className="scroll-reveal">
            <div className="space-y-8">
              {/* Contact Info */}
              <Card className="bg-nexo-black text-white p-8 rounded-2xl" data-testid="contact-info-card">
                <CardContent className="p-0">
                  <h3 className="font-montserrat font-bold text-2xl mb-6">
                    Información de Contacto
                  </h3>

                  <div className="space-y-6">
                    <div className="flex items-start">
                      <div className="bg-nexo-red text-white p-3 rounded-full mr-4 flex-shrink-0">
                        <MapPin size={20} />
                      </div>
                      <div>
                        <h4 className="font-semibold mb-1">Dirección</h4>
                        <p className="text-gray-300" data-testid="contact-address">
                          Col. Palmira, Blvd. Morazán<br />
                          Tegucigalpa, Honduras
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start">
                      <div className="bg-nexo-red text-white p-3 rounded-full mr-4 flex-shrink-0">
                        <Phone size={20} />
                      </div>
                      <div>
                        <h4 className="font-semibold mb-1">Teléfono</h4>
                        <p className="text-gray-300" data-testid="contact-phone">
                          +504 2234-5678
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start">
                      <div className="bg-nexo-red text-white p-3 rounded-full mr-4 flex-shrink-0">
                        <Mail size={20} />
                      </div>
                      <div>
                        <h4 className="font-semibold mb-1">Email</h4>
                        <p className="text-gray-300" data-testid="contact-email">
                          info@nexofit.hn
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start">
                      <div className="bg-nexo-red text-white p-3 rounded-full mr-4 flex-shrink-0">
                        <Clock size={20} />
                      </div>
                      <div>
                        <h4 className="font-semibold mb-1">Horarios</h4>
                        <p className="text-gray-300" data-testid="contact-hours">
                          Lun-Vie: 5:00 AM - 10:00 PM<br />
                          Sáb-Dom: 6:00 AM - 8:00 PM
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="border-t border-gray-700 pt-6 mt-6">
                    <h4 className="font-semibold mb-4">Síguenos</h4>
                    <div className="flex space-x-4" data-testid="social-media-links">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleSocialClick("Instagram")}
                        className="bg-nexo-red text-white p-3 rounded-full hover:bg-red-700 transition-colors"
                        data-testid="social-instagram"
                      >
                        <Instagram size={20} />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleSocialClick("Facebook")}
                        className="bg-nexo-red text-white p-3 rounded-full hover:bg-red-700 transition-colors"
                        data-testid="social-facebook"
                      >
                        <Facebook size={20} />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleSocialClick("YouTube")}
                        className="bg-nexo-red text-white p-3 rounded-full hover:bg-red-700 transition-colors"
                        data-testid="social-youtube"
                      >
                        <Youtube size={20} />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Map Placeholder */}
              <div 
                className="bg-gray-300 h-64 rounded-2xl flex items-center justify-center"
                data-testid="map-placeholder"
              >
                <div className="text-center text-gray-600">
                  <MapPin size={48} className="mx-auto mb-2" />
                  <p className="font-semibold">Mapa Interactivo</p>
                  <p className="text-sm">Ubicación de NexoFit</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
