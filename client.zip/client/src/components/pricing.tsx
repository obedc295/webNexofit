import { Check } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

const plans = [
  {
    id: "basic",
    name: "Básico",
    description: "Ideal para comenzar tu transformación",
    price: "L.800",
    features: [
      "Acceso completo al gimnasio",
      "Evaluación inicial gratuita",
      "Horarios flexibles",
      "Casilleros incluidos",
    ],
    buttonClass: "bg-gray-900 text-white hover:bg-nexo-red",
    popular: false,
  },
  {
    id: "advanced",
    name: "Avanzado",
    description: "Para atletas comprometidos",
    price: "L.1,200",
    features: [
      "Todo del plan Básico",
      "2 sesiones de entrenamiento personal",
      "Acceso a la app NexoFit",
      "Plan nutricional básico",
      "Descuentos en suplementos",
    ],
    buttonClass: "bg-white text-nexo-red hover:bg-gray-100",
    popular: true,
  },
  {
    id: "premium",
    name: "Premium",
    description: "Experiencia completa de élite",
    price: "L.1,800",
    features: [
      "Todo del plan Avanzado",
      "Entrenamiento personal ilimitado",
      "Plan nutricional personalizado",
      "Suplementos incluidos",
      "Acceso a áreas VIP",
      "Soporte 24/7",
    ],
    buttonClass: "bg-nexo-red text-white hover:bg-red-700",
    popular: false,
  },
];

export default function Pricing() {
  const handleSelectPlan = (planId: string) => {
    const element = document.getElementById("contacto");
    if (element) {
      element.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  };

  return (
    <section 
      id="planes" 
      className="py-20 bg-white"
      data-testid="pricing-section"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16 scroll-reveal">
          <h2 
            className="font-montserrat font-bold text-4xl md:text-5xl text-nexo-black mb-4"
            data-testid="section-title"
          >
            Planes <span className="text-nexo-red">Diseñados</span> Para Ti
          </h2>
          <p 
            className="text-xl text-gray-600 max-w-3xl mx-auto"
            data-testid="section-subtitle"
          >
            Elige el plan que mejor se adapte a tus objetivos de entrenamiento
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {plans.map((plan, index) => (
            <div key={plan.id} className="scroll-reveal">
              <Card
                className={`
                  ${plan.popular 
                    ? "bg-nexo-red text-white rounded-2xl p-8 relative card-hover transform scale-105" 
                    : plan.id === "premium" 
                      ? "bg-nexo-black text-white rounded-2xl p-8 relative card-hover"
                      : "bg-white border-2 border-gray-200 rounded-2xl p-8 relative card-hover"
                  }
                `}
                data-testid={`pricing-card-${plan.id}`}
              >
                {plan.popular && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <span className="bg-nexo-black text-white px-6 py-2 rounded-full text-sm font-semibold">
                      MÁS POPULAR
                    </span>
                  </div>
                )}

                <CardContent className="p-0">
                  <div className="text-center">
                    <h3 
                      className="font-montserrat font-bold text-2xl mb-2"
                      data-testid={`plan-name-${plan.id}`}
                    >
                      {plan.name}
                    </h3>
                    <p 
                      className={`mb-6 ${
                        plan.popular ? "text-red-100" : 
                        plan.id === "premium" ? "text-gray-300" : 
                        "text-gray-600"
                      }`}
                      data-testid={`plan-description-${plan.id}`}
                    >
                      {plan.description}
                    </p>
                    <div className="mb-8">
                      <span 
                        className="text-4xl font-bold"
                        data-testid={`plan-price-${plan.id}`}
                      >
                        {plan.price}
                      </span>
                      <span 
                        className={
                          plan.popular ? "text-red-100" : 
                          plan.id === "premium" ? "text-gray-300" : 
                          "text-gray-600"
                        }
                      >
                        /mes
                      </span>
                    </div>
                  </div>

                  <ul className="space-y-4 mb-8" data-testid={`plan-features-${plan.id}`}>
                    {plan.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-center">
                        <Check 
                          className={`mr-3 ${
                            plan.popular ? "text-white" : 
                            plan.id === "premium" ? "text-nexo-red" : 
                            "text-nexo-red"
                          }`} 
                          size={20} 
                        />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>

                  <Button
                    onClick={() => handleSelectPlan(plan.id)}
                    className={`w-full py-3 rounded-full font-semibold transition-colors ${plan.buttonClass}`}
                    data-testid={`button-select-plan-${plan.id}`}
                  >
                    Seleccionar Plan
                  </Button>
                </CardContent>
              </Card>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
