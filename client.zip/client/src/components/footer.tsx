import { MapPin, Phone, Mail, Instagram, Facebook, Youtube } from "lucide-react";

export default function Footer() {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  };

  const handleSocialClick = (platform: string) => {
    // Placeholder for social media links
    alert(`Redirigiendo a ${platform}...`);
  };

  return (
    <footer className="bg-nexo-black text-white py-12" data-testid="footer">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="md:col-span-2">
            <div 
              className="font-montserrat font-bold text-3xl mb-4"
              data-testid="footer-brand"
            >
              NEXO<span className="text-nexo-red">FIT</span>
            </div>
            <p 
              className="text-gray-300 mb-6 max-w-md"
              data-testid="footer-description"
            >
              El gimnasio líder en Tegucigalpa especializado en jóvenes atletas.
              Transformamos potencial en rendimiento excepcional.
            </p>
            <div className="flex space-x-4" data-testid="footer-social-links">
              <button
                onClick={() => handleSocialClick("Instagram")}
                className="text-gray-300 hover:text-nexo-red transition-colors"
                data-testid="footer-social-instagram"
              >
                <Instagram size={24} />
              </button>
              <button
                onClick={() => handleSocialClick("Facebook")}
                className="text-gray-300 hover:text-nexo-red transition-colors"
                data-testid="footer-social-facebook"
              >
                <Facebook size={24} />
              </button>
              <button
                onClick={() => handleSocialClick("YouTube")}
                className="text-gray-300 hover:text-nexo-red transition-colors"
                data-testid="footer-social-youtube"
              >
                <Youtube size={24} />
              </button>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 
              className="font-montserrat font-bold text-lg mb-4"
              data-testid="footer-links-title"
            >
              Enlaces Rápidos
            </h4>
            <ul className="space-y-2" data-testid="footer-quick-links">
              <li>
                <button
                  onClick={() => scrollToSection("inicio")}
                  className="text-gray-300 hover:text-nexo-red transition-colors"
                  data-testid="footer-link-inicio"
                >
                  Inicio
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollToSection("mision-vision")}
                  className="text-gray-300 hover:text-nexo-red transition-colors"
                  data-testid="footer-link-nosotros"
                >
                  Nosotros
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollToSection("planes")}
                  className="text-gray-300 hover:text-nexo-red transition-colors"
                  data-testid="footer-link-planes"
                >
                  Planes
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollToSection("servicios")}
                  className="text-gray-300 hover:text-nexo-red transition-colors"
                  data-testid="footer-link-servicios"
                >
                  Servicios
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollToSection("galeria")}
                  className="text-gray-300 hover:text-nexo-red transition-colors"
                  data-testid="footer-link-galeria"
                >
                  Galería
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollToSection("contacto")}
                  className="text-gray-300 hover:text-nexo-red transition-colors"
                  data-testid="footer-link-contacto"
                >
                  Contacto
                </button>
              </li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 
              className="font-montserrat font-bold text-lg mb-4"
              data-testid="footer-contact-title"
            >
              Contacto
            </h4>
            <ul className="space-y-2 text-gray-300" data-testid="footer-contact-info">
              <li className="flex items-center">
                <MapPin className="text-nexo-red mr-2" size={16} />
                <span className="text-sm">Col. Palmira, Tegucigalpa</span>
              </li>
              <li className="flex items-center">
                <Phone className="text-nexo-red mr-2" size={16} />
                <span className="text-sm">+504 2234-5678</span>
              </li>
              <li className="flex items-center">
                <Mail className="text-nexo-red mr-2" size={16} />
                <span className="text-sm">info@nexofit.hn</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Copyright */}
        <div className="border-t border-gray-700 mt-8 pt-8 text-center">
          <p className="text-gray-300" data-testid="footer-copyright">
            © 2024 NexoFit. Todos los derechos reservados. |{" "}
            <button className="text-nexo-red hover:underline">Política de Privacidad</button> |{" "}
            <button className="text-nexo-red hover:underline">Términos de Servicio</button>
          </p>
        </div>
      </div>
    </footer>
  );
}
