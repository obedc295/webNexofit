import { Quote, Star } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

const testimonials = [
  {
    id: "maria",
    content: "NexoFit transformó completamente mi entrenamiento. La app es increíble y los entrenadores realmente entienden las necesidades de los jóvenes atletas. ¡Mis resultados hablan por sí solos!",
    name: "María Rodríguez",
    sport: "Atleta de Crossfit",
    initials: "MR",
  },
  {
    id: "carlos",
    content: "Llevo 8 meses en NexoFit y puedo decir que es la mejor inversión que he hecho. El equipamiento es de primera clase y el ambiente motiva a dar siempre el máximo.",
    name: "Carlos López",
    sport: "Futbolista",
    initials: "CL",
  },
  {
    id: "ana",
    content: "La atención personalizada y el plan nutricional han sido clave en mi progreso. NexoFit realmente entiende lo que los atletas jóvenes necesitamos para destacar.",
    name: "Ana Vargas",
    sport: "Atleta de Pista",
    initials: "AV",
  },
];

export default function Testimonials() {
  return (
    <section 
      className="py-20 bg-nexo-black text-white"
      data-testid="testimonials-section"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16 scroll-reveal">
          <h2 
            className="font-montserrat font-bold text-4xl md:text-5xl mb-4"
            data-testid="section-title"
          >
            Lo Que Dicen Nuestros <span className="text-nexo-red">Atletas</span>
          </h2>
          <p 
            className="text-xl text-gray-300 max-w-3xl mx-auto"
            data-testid="section-subtitle"
          >
            Historias reales de transformación y éxito de nuestra comunidad
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <div key={testimonial.id} className="scroll-reveal">
              <Card 
                className="bg-gray-900 p-6 rounded-2xl card-hover"
                data-testid={`testimonial-card-${testimonial.id}`}
              >
                <CardContent className="p-0">
                  <div className="flex items-center mb-4">
                    <div className="text-nexo-red text-3xl mr-2">
                      <Quote size={24} />
                    </div>
                    <div className="flex text-nexo-red" data-testid={`testimonial-rating-${testimonial.id}`}>
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} size={16} fill="currentColor" />
                      ))}
                    </div>
                  </div>
                  
                  <p 
                    className="text-gray-300 mb-6 leading-relaxed"
                    data-testid={`testimonial-content-${testimonial.id}`}
                  >
                    "{testimonial.content}"
                  </p>
                  
                  <div className="flex items-center">
                    <div className="w-12 h-12 bg-nexo-red rounded-full flex items-center justify-center mr-4">
                      <span 
                        className="font-bold text-white"
                        data-testid={`testimonial-initials-${testimonial.id}`}
                      >
                        {testimonial.initials}
                      </span>
                    </div>
                    <div>
                      <h4 
                        className="font-semibold"
                        data-testid={`testimonial-name-${testimonial.id}`}
                      >
                        {testimonial.name}
                      </h4>
                      <p 
                        className="text-gray-400 text-sm"
                        data-testid={`testimonial-sport-${testimonial.id}`}
                      >
                        {testimonial.sport}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
